package devopsapp.selenium;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxBinary;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import net.sourceforge.jwebunit.api.IElement;

import org.openqa.selenium.firefox.FirefoxOptions;



import org.junit.*;
import static org.junit.Assert.*;

import java.io.File;

import org.junit.experimental.categories.Category;

//@Category(IntegrationTest.class)
public class LoginFunctionalTest {

	static WebDriver driver;
	String baseURL="http://localhost:7070/devOpsApp/user";

	@BeforeClass
	public static void setup() {
	//	driver = new ChromeDriver();
		// new FirefoxDriver();
				FirefoxBinary firefoxBinary = new FirefoxBinary();
        firefoxBinary.addCommandLineOptions("--headless");
        System.setProperty("webdriver.gecko.driver", "/opt/firefoxdriver/geckodriver");
        FirefoxOptions firefoxOptions = new FirefoxOptions();
        firefoxOptions.setBinary(firefoxBinary);
        
        driver = new FirefoxDriver(firefoxOptions);
	}

	@AfterClass
	public static void cleanUp() {
		driver.quit();
	}
	
	@Test
	public void testGetMessage() {
        driver.get(baseURL+"/");
        String title =driver.getTitle();
        assertEquals("Welcome Page",title);
        assertTrue(driver.getPageSource().contains("Hello, This is message from service for user/"));
	}
//
	
	@Test
	public void testGetWelcomePage() {
        driver.get(baseURL+"/getwelcomepage");
        String title =driver.getTitle();
        assertEquals("Welcome Page",title);
        assertTrue(driver.getPageSource().contains("### Welcome to User management Home page ###"));
	}
	
	@Test
	public void testGetLoginRegister() {
        driver.get(baseURL+"/getloginregister");
        String title =driver.getTitle();
        assertEquals("Sign in Or Register",title);
        assertTrue(driver.getPageSource().contains("Welcome !! Signin to find all registered Users"));
	}
	
	@Test
	public void loginProcessSuccess() {
        driver.get(baseURL+"/getloginregister");
        WebElement selectLogin = driver.findElement(By.xpath("/html/body/div/div/div/div/div/div/button"));
        selectLogin.click();
        WebElement email = driver.findElement(By.name("email"));
        WebElement pass = driver.findElement(By.name("password"));
        WebElement submitLogin = driver.findElement(By.xpath("/html/body/div/div/div/div/div/form/button"));         
        email.sendKeys("abc@abc.com");
        pass.sendKeys("1234");
        submitLogin.click();
        assertTrue(driver.getPageSource().contains("!!! This Login Process Response !!!"));
	}
	
//	//@Test
//	public void loginFail() {
//        driver.get("http://localhost:5050/mar3seleniumtest");
//        WebElement email = driver.findElement(By.name("email"));
//        WebElement pass = driver.findElement(By.name("password"));
//        WebElement button = driver.findElement(By.xpath("/html/body/form/div/button"));         
//        email.sendKeys("avinash.patel@wipro.com");
//        pass.sendKeys("1234566666666");
//        button.click();
//        assertTrue(driver.getPageSource().contains("Invalid username or password, Please try again with valid"));
//	}
//	
//	//@Test
//	public void registrationSuccess() {
//        driver.get("http://localhost:5050/mar3seleniumtest/register.jsp");
//        WebElement firstname = driver.findElement(By.name("firstname"));
//        WebElement lastname = driver.findElement(By.name("lastname"));
//        WebElement confirmpass = driver.findElement(By.name("confirmpass"));
//        WebElement email = driver.findElement(By.name("email"));
//        WebElement pass = driver.findElement(By.name("pass"));
//        WebElement button = driver.findElement(By.xpath("/html/body/form/div/button"));      
//        firstname.sendKeys("fname");
//        lastname.sendKeys("lname");
//        pass.sendKeys("1234");
//        confirmpass.sendKeys("1234");
//        email.sendKeys("aa@gmail.com");
//        button.click();
//        assertTrue(driver.getPageSource().contains("Book Store"));
//	}
//	
//	//@Test
//	public void forgotPasswordSuccess() {
//        driver.get("http://localhost:5050/mar3seleniumtest/forgotpassword.jsp");      
//        WebElement confirmpass = driver.findElement(By.name("confirmpassword"));
//        WebElement email = driver.findElement(By.name("email"));
//        WebElement pass = driver.findElement(By.name("newpassword"));
//        WebElement button = driver.findElement(By.xpath("/html/body/form/div/button"));      
//        pass.sendKeys("1234");
//        confirmpass.sendKeys("1234");
//        email.sendKeys("avinash.patel@wipro.com");
//        button.click();
//        assertTrue(driver.getPageSource().contains("Book Store"));
//	}
}
