package devopsapp.selenium;




public interface IntegrationTest {

}
