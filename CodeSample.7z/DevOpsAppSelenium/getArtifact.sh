#!/bin/bash
# Artifactory settings
host="127.0.0.1:8082"
username="devops"
password="devops!devops"
groupId="devops/ilp1"
artifactId="app-source"
version="1.0.1-"

#devops/ilp1/app-source/1.0.1-34/app-source-1.0.1-34.war
# Use Artifactory Query Language to get the latest scraper script (https://www.jfrog.com/confluence/display/RTF/Artifactory+Query+Language)
resultAsJson=$(
		curl -u $username:$password -X POST  http://$host/artifactory/api/search/aql -H "content-type: text/plain" -d 'items.find({ "repo": {"$eq":"libs-release-local"}, "name": {"$match" : "app-source*"}})'
		)
#echo $resultAsJson

# Use ./jq to pars JSON
latestFile=$(echo $resultAsJson | jq -r '.results | sort_by(.updated) [-1].name')

#echo $latestFile

#Extract build.number
buildnumber=$(echo "app-source-1.0.1-34.war"|grep -P '\w+(?=.war)' -o)
#echo $buildnumber

artifactpath="$groupId/$artifactId/$version$buildnumber/$latestFile"
echo "Constructed path= "$artifactpath

# Download the latest scraper script 
wget --user $username --password $password http://$host/artifactory/libs-release-local/$artifactpath
sudo cp /home/osgdev/Downloads/app-source-1.0.1-34.war /opt/seleniumtest/tomcat/apache-tomcat-8.5.57/webapps/ILP_Bookstore.war
echo "test env. is getting configured"
#echo 'osg@1234' | sudo -S systemctl start seleniumtomcat.service 
echo 'osg@1234' | sudo -S systemctl restart seleniumtomcat.service
echo "sleep for 15 seconds"
sleep 15
echo "test env. is ready tomcat running at 6080"

