package demo.appbuild;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DevOpsAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
