package snippet;

public class Snippet {
	@Before
	public void truncateTables() {
	    //truncate tables
	}
}

