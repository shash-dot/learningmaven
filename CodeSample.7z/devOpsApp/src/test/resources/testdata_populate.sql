insert into user(name,email,password) values
	('testname1','testemail1','testpwd1'),
	('testname2','testemail2','testpwd2'),
	('testname3','testemail3','testpwd3'),
	('testname4','testemail4','testpwd4');
