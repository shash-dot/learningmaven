insert into user(id, name,email,password) values
	(101,'name1','email1','pwd1'),
	(102,'name2','email2','pwd2'),
	(103,'name3','email3','pwd3');
